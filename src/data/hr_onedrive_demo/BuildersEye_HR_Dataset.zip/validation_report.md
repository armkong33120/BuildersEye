# BuildersEye HR OneDrive Demo - Validation Report

**Generated:** 2026-07-15 05:48:23

**Employee files:** 150
**Master index:** BuildersEye_HR_Master_Index.xlsx

## Validation Results

| # | Check | Result | Detail |
|---|---|---|---|
| 1 | 150 employee files | PASS | Found 150 |
| 2 | Master index exists | PASS | /Users/arm/AI Test/mail-onedrive-org-graph/src/data/hr_onedrive_demo/BuildersEye_HR_Master_Index.xlsx |
| 3 | All files open | PASS | 0 failures |
| 4 | All 12 sheets present | PASS | 0 with missing sheets |
| 5 | KPI band diversity (A-E all present) | PASS | A=6, B=59, C=492, D=232, E=5 |
| 6 | All have projects | PASS | Missing: 0 |
| 7 | All have KPIs | PASS | Missing: 0 |
| 8 | All have warnings | PASS | Missing: 0 |
| 9 | All have learning | PASS | Missing: 0 |
| 10 | All have collaborators | PASS | Missing: 0 |

## Dataset Inventory

| Dataset | Records |
|---|---|
| identity-graph.json | 150 employees |
| career-story-plan.json | 150 stories |
| kpi-okr-history.json | 794 review periods |
| project-assignments.json | 633 assignments |
| collaboration-graph.json | 5331 edges |
| warning-history.json | 291 cases |
| learning-history.json | 528 training records |
| master-index.json | 150 employees |
| it-assets.json | 170 assets |
| it-tickets.json | 168 tickets |
| software-licenses.json | 174 licenses |
| salary-history.json | 150 employees |
| attendance-record.json | 150 employees |
| **Excel files** | **150** employee files + 1 master index |

## KPI Band Distribution

- Exceptional (A): 6
- Exceeds (B): 59
- Meets (C): 492
- Below (D): 232
- Unsatisfactory (E): 5

## Known Limitations

1. Executives have >7 project assignments (by design - they sponsor many initiatives)
2. Collaboration graph edges may exceed 5-12 range (full edge graph from LOOP 5 included)
3. KPI scores may show floating-point artifacts (Excel formatting rounds to 1 decimal)
4. Salary-related fields redacted for Tier 1/2 employees per HR confidentiality rules
5. All data is synthetic/fictional - no real personal data used

## Final Verdict

**Overall: ALL CHECKS PASSED**

**10/10 checks passed**